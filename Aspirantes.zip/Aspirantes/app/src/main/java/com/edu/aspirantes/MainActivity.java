package com.edu.aspirantes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.edu.aspirantes.model.Aspirantes;

public class MainActivity extends AppCompatActivity {
    EditText txtNombre;
    EditText txtProBa;
    Spinner spnTipoBa;
    Spinner spnCarrera;
    Button btnResultado;
    Button btnNuevo;
    Button btnSalir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNombre= findViewById(R.id.eTxtNombre);
        txtProBa = findViewById(R.id.eTxtPromBa);
        btnResultado = findViewById(R.id.buttonResultados);
        btnNuevo = findViewById(R.id.buttonNuevo);
        btnSalir = findViewById(R.id.buttonSalir);
        spnTipoBa = findViewById(R.id.spnTipoBa);
        spnCarrera = findViewById(R.id.spnCarrera);

        ArrayAdapter<CharSequence> adapBa = ArrayAdapter.createFromResource(this,
                R.array.tipoBachillerato,
                android.R.layout.simple_spinner_dropdown_item);
        adapBa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnTipoBa.setAdapter(adapBa);

        ArrayAdapter<CharSequence> adapCa = ArrayAdapter.createFromResource(this,R.array.carrera,
                android.R.layout.simple_spinner_dropdown_item);
        adapCa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCarrera.setAdapter(adapCa);

        //BOTON RESULTADOS
        btnResultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = txtNombre.getText().toString().trim();
                String prom = txtProBa.getText().toString().trim();

                try {
                    if (nombre.length() ==0 || prom.length()==0){
                        Toast.makeText(getApplicationContext(), "No dejes campos vacios", Toast.LENGTH_SHORT).show();
                    }else if(Integer.parseInt(prom)<0){
                        Toast.makeText(getApplicationContext(), "Valor invalido en promedio", Toast.LENGTH_SHORT).show();
                    }else if(spnTipoBa.getSelectedItemPosition()==0 || spnCarrera.getSelectedItemPosition()==0){
                        Toast.makeText(getApplicationContext(), "Selecciona un campo", Toast.LENGTH_SHORT).show();
                    }else {

                        Aspirantes asp = new Aspirantes();
                        asp.setNombre(nombre);
                        asp.setPromedioBa(Double.parseDouble(prom));
                        asp.setTipoBa(spnTipoBa.getSelectedItemPosition());
                        asp.setCarrera(spnCarrera.getSelectedItem().toString());
                        Toast.makeText(getApplicationContext(), asp.estatus()
                                , Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception ex){
                    Toast.makeText(getApplicationContext(), "Coloca valores válidos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //BOTON SALIR
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //BOTON NUEVO
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtNombre.setText(null);
                txtProBa.setText(null);
                spnTipoBa.setSelection(0);
                spnCarrera.setSelection(0);
            }
        });

    }
}